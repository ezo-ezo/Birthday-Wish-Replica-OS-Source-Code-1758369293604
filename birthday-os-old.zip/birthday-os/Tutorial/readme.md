## First follow these instructions carefully and only contact me if its not working. 

# My Video tutorials : 
---> For getting the sharable link : https://youtu.be/bFCnDsQwNvA


Required Softwares : Git Bash, VS Code, Node JS

# SetUp Instructions

1. install vs code if you dont have in your system.

Tutorial:
https://youtu.be/3eCmc0t6aqA?si=TkV0bVEz_95FbMmi


2. install nodejs if you dont have in your system. 

Tutorial: 
https://youtu.be/uCgAuOYpJd0?si=2ICwr3Ih1P_ru9KA

3. These two are required to run the code otherwise it'll not work

4. Now open the "birthday-os" folder in vs code.

5. Now open the terminal in vs code 

6. type "npm i" or "npm install" in the terminal and press enter

## if you get any error saying script is not installed then, use this command :

Set-ExecutionPolicy -Scope CurrentUser Unrestricted


8. type "npm run dev" in the terminal and press enter

9. now you will get a local host link, you can CTRL + press and click on the link to view the website in your local system.

10. if you want to share with someone then you will have to host it.

12. Refer to my video for hosting it :
https://youtu.be/bFCnDsQwNvA




# Modification Instructions: 

1. Changing Background Image
To change the wallpaper, replace the image file:

Location: src/components/assets/wall.gif

- Replace this file with your own image
- Keep the same name: wall.gif
- Best size: 1920x1080 pixels

2. Adding Your Own Photos
Location: src/components/assets/imgs/

- Replace img1.jpg, img2.jpg, img3.jpg with your photos
- Keep the same names

3. Changing Love Letters
use CTRL + F to find the texts, and edit them


4. Adding Your Music
Location: src/components/assets/music/

- Add your music files (MP3 format)

- Replace music1.mp3, music2.mp3, music3.mp3 with your own music
- Keep the same names


5. To change the text of other pages, 
- you need to go to src/components/apps 
- and change the content of the each file by your own

- change text in desktop.tsx (optional)
- change text in app.tsx (optional)